<?php include('menu.php');?>
    <section class="categories">
        <div class="container">
            <h2 class="text-center">Explore Foods</h2>

            <?php
                $query="SELECT id,title,image_name FROM tbl_category WHERE active ='Yes'";
                $val=mysql_query($query);
                $temp_img = "";
                while(list($id,$title,$image) = mysql_fetch_array($val))
                {
                    if($image==""){
                        $image="<div class='delete'>Image Not Available</div>";
                    }
                    else{
                        $temp_img = $image; 
                        $image="<img src='images/category/$image' alt='$title' class='img-responsive img-curve'>";
                    }
                echo "<a href='category-foods.php?id=$id&title=$title'>
                        <div class='box-3 float-container'>
                            $image
                            <h3 class='float-text text-white'>$title</h3>
                        </div>
                    </a>";
                }
            ?>
            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Categories Section Ends Here -->
<?php include('footer.php');?>