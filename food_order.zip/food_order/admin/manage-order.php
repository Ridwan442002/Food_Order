<?php include('menu.php');?>
    <div class="main-content">
        <div class="wrapper">
            <h1 class='text-center'>Manage Order</h1>
            <br>
            <?php
                error_reporting(1);
                if($_SESSION['message']!=""){
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                }
            ?>
            <br>
            <table class='tbl-full'>
                <tr>
                    <th>Id</th>
                    <th>Food</th>
                    <th>Price</th>
                    <th>Qty</th>
                    <th>Total</th>
                    <th>Order_Date</th>
                    <th>Status</th>
                    <th>Name</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Actions</th>
                </tr>
                <?php
                $query="SELECT * FROM tbl_order";
                $val=mysql_query($query);
                if(mysql_num_rows($val) <= 0){
                    echo "<tr><td colspan='12' class='delete text-center'>Food didn't add yet!!!</td></tr>";
                }
                else{
                    while(list($id,$food,$price,$qty,$total,$date,$status,$name,$contact,$email,$address) = mysql_fetch_array($val))
                    {
                        echo "<tr>";
                            echo "<td>".$id."</td>";
                            echo "<td>".$food."</td>";
                            echo "<td>".$price."</td>";
                            echo "<td>".$qty."</td>";
                            echo "<td>".$total."</td>";
                            echo "<td>".$date."</td>";
                            echo "<td>".$status."</td>";
                            echo "<td>".$name."</td>";
                            echo "<td>".$contact."</td>";
                            echo "<td>".$email."</td>";
                            echo "<td>".$address."</td>";
                            echo "
                                    <td>
                                        <a href='update-order.php?id=$id' class='btn-secondary'>Update</a>
                                    </td>
                                ";
                        echo "</tr>";
                    }
                }
                ?>
            </table>
        </div>
    </div>
<?php include('footer.php');?>