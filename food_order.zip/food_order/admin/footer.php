    <div class="footer">
        <div class="wrapper">
            <p class="text-center">2024 All rights reserved, Some Restaurant. Developed By <a href="#">Ridwan</a></p>
        </div>
    </div>
</body>
</html>