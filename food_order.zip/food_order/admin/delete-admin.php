<?php include('menu.php');?>
<?php

$id = $_GET[id];
$query = "DELETE FROM tbl_admin WHERE id = $id";
if(mysql_query($query)){
    session_start();
    $_SESSION['message'] = "<div class='delete'>Admin deleted successfully</div>";
    header("location:manage-admin.php");
}else{
    echo "Error: ".mysql_error();
}

?>