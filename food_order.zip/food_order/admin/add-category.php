<?php include('menu.php')?>

<div class="main-content">
    <div class="wrapper">
        <h1>Add Category</h1>
        <br>
            <?php
            error_reporting(1);
            if($_SESSION['message']!=""){
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            }
            ?>
        <br>

        <form action="" method="post" enctype="multipart/form-data">
            <table class="tbl-40">
                <tr>
                    <td>Title : </td>
                    <td>
                        <input type="text" name="title" placeholder="Enter a title">
                    </td>
                </tr>
                <tr>
                    <td>Image : </td>
                    <td>
                        <input type="file" name="image">
                    </td>
                </tr>
                <tr>
                    <td>Featured : </td>
                    <td>
                        <input type="radio" name="featured" value="Yes"> Yes
                        <input type="radio" name="featured" value="No"> No
                    </td>
                </tr>
                <tr>
                    <td>Active : </td>
                    <td>
                        <input type="radio" name="active" value="Yes"> Yes
                        <input type="radio" name="active" value="No"> No
                    </td>
                </tr>
                <tr>
                    <td colspan=2>
                        <input type="submit" name="submit" value="Add Category" class="btn-secondary">
                    </td>
                </tr>
            </table>
        </form>
        
    </div>
</div>

<?php include('footer.php')?>

<?php 

if(isset($_POST['submit'])){
    $title = $_POST['title'];
    if(isset($_POST['featured'])){
        $featured = $_POST['featured'];
    }
    else{
        $featured = "No";
    }
    if(isset($_POST['active'])){
        $active = $_POST['active'];
    }
    else{
        $active = "No";
    }

    if(isset($_FILES['image']['name'])){
        $image = $_FILES['image']['name'];
        if($image != ""){
            $ext = end(explode('.',$image));
            $image = "Food_Category_".rand(111,999).".".$ext;
            $source = $_FILES['image']['tmp_name'];
            $path = '../images/category/'.$image;
            $upload = move_uploaded_file($source,$path);
            if(!$upload){
                $_SESSION['message'] = "<div class='delete'>Failed upload image</div>";
                header("location:add-category.php");
                die();
            }
        }
    }
    else{
        $image = "";
    }
    
    $query = "INSERT INTO tbl_category(title,image_name,featured,active)
    VALUES('$title','$image','$featured','$active')";
    $result = mysql_query($query);
    if($result){
        $_SESSION['message'] = "<div class='add'>Added category successfully</div>";
        header("location:manage-category.php");
    }
    else{
        $_SESSION['message'] = "<div class='delete'>Failed add category</div>";
        header("location:add-category.php");
    }
}

?>