<?php include('menu.php');?>

<?php
    $id = $_GET['id'];
    $query="SELECT * FROM tbl_admin WHERE id = '".$_GET['id']."'";
    $val=mysql_query($query);
    list($id,$fname,$uname,$pass) = mysql_fetch_array($val);
?>

<div class="main-content">
        <div class="wrapper">
            <h1>Update Admin</h1>

            <form action="" method="POST">
                <table class="tbl-40">
                    <tr>
                        <td>Fullname: </td>
                        <td><input type="text" name="fullname" value="<?php echo $fname?>"></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Username: </td>
                        <td><input type="text" name="username" value="<?php echo $uname?>"></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <input type="submit" value="Update admin" name="submit" class="btn-secondary">
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
<?php include('footer.php');?>

<?php

if(isset($_POST['submit'])){
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];

    $query = "UPDATE tbl_admin SET full_name='$fullname',username='$username' WHERE id=$id";
    if(mysql_query($query)){
        session_start();
        $_SESSION['message'] = "<div class='add'>Admin's Info Updated successfully</div>";
        header("location:manage-admin.php");
    }
    else{
        echo "Error: ".mysql_error();
    }
}

?>