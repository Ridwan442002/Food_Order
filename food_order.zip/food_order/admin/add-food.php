<?php include('menu.php')?>

<div class="main-content">
    <div class="wrapper">
        <h1>Add Food</h1>
        <br>
            <?php
            error_reporting(1);
            if($_SESSION['message']!=""){
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            }
            ?>
        <br>

        <form action="" method="post" enctype="multipart/form-data">
            <table class="tbl-40">
                <tr>
                    <td>Title : </td>
                    <td>
                        <input type="text" name="title" placeholder="Enter a title">
                    </td>
                </tr>
                <tr>
                    <td>Description : </td>
                    <td>
                        <textarea name="description" cols="25" rows="5" placeholder="Description of the food"></textarea>
                    </td>
                </tr>
                <tr>
                    <td>Price : </td>
                    <td>
                        <input type="number" name="price" placeholder="Enter a price">
                    </td>
                </tr>
                <tr>
                    <td>Image : </td>
                    <td>
                        <input type="file" name="image">
                    </td>
                </tr>
                <tr>
                    <td>Category : </td>
                    <td>
                        <select name="category">
                            <?php
                                $query = "SELECT id,title FROM tbl_category WHERE active='Yes'";
                                $val=mysql_query($query);
                                if(mysql_num_rows($val) <= 0){
                                    echo "<option value='0'>No Category Found</option>";
                                }
                                else{
                                    while(list($id,$title) = mysql_fetch_array($val))
                                    {
                                        echo "<option value='$id'>$title</option>";
                                    }
                                }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Featured : </td>
                    <td>
                        <input type="radio" name="featured" value="Yes"> Yes
                        <input type="radio" name="featured" value="No"> No
                    </td>
                </tr>
                <tr>
                    <td>Active : </td>
                    <td>
                        <input type="radio" name="active" value="Yes"> Yes
                        <input type="radio" name="active" value="No"> No
                    </td>
                </tr>
                <tr>
                    <td colspan=2>
                        <input type="submit" name="submit" value="Add Food" class="btn-secondary">
                    </td>
                </tr>
            </table>
        </form>
        
    </div>
</div>

<?php include('footer.php')?>

<?php 

if(isset($_POST['submit'])){
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    if(isset($_POST['featured'])){
        $featured = $_POST['featured'];
    }
    else{
        $featured = "No";
    }
    if(isset($_POST['active'])){
        $active = $_POST['active'];
    }
    else{
        $active = "No";
    }

    if(isset($_FILES['image']['name'])){
        $image = $_FILES['image']['name'];
        if($image != ""){
            $ext = end(explode('.',$image));
            $image = "Food_".rand(111,999).".".$ext;
            $source = $_FILES['image']['tmp_name'];
            $path = '../images/food/'.$image;
            $upload = move_uploaded_file($source,$path);
            if(!$upload){
                $_SESSION['message'] = "<div class='delete'>Failed upload image</div>";
                header("location:add-category.php");
                die();
            }
        }
    }
    else{
        $image = "";
    }
    
    $query = "INSERT INTO tbl_food(title,description,price,image_name,category_id,featured,active)
    VALUES('$title','$description',$price,'$image',$category,'$featured','$active')";
    $result = mysql_query($query);
    if($result){
        $_SESSION['message'] = "<div class='add'>Added food successfully</div>";
        header("location:manage-food.php");
    }
    else{
        $_SESSION['message'] = "<div class='delete'>Failed add food</div>";
        header("location:add-food.php");
    }
}

?>