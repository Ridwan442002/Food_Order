<?php
    session_start();
    if(!isset($_SESSION['login'])){
        header("location:login.php");
        $_SESSION['login_first'] = "<div class='delete text-center'>Please Login First!!!</div>";
    }
?>