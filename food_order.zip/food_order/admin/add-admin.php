<?php include('menu.php');?>

    <div class="main-content">
        <div class="wrapper">
            <h1>Add Admin</h1>

            <form action="" method="POST">
                <table class="tbl-30">
                    <tr>
                        <td>Fullname: </td>
                        <td><input type="text" name="fullname" placeholder="Enter Your Name"></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Username: </td>
                        <td><input type="text" name="username" placeholder="Enter Userame"></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Password: </td>
                        <td><input type="password" name="password" placeholder="Enter Password"></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Fullname: </td>
                        <td><input type="text" name="" placeholder="Enter Password"></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <input type="submit" value="Add admin" name="submit" class="btn-secondary">
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
<?php include('footer.php');?>

<?php

if(isset($_POST['submit'])){
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];
    $password = md5($_POST['password']);

    $query = "INSERT INTO tbl_admin(full_name,username,password)
    VALUES ('$fullname','$username','$password')";
    if(mysql_query($query)){
        session_start();
        $_SESSION['message'] = "<div class='add'>Admin added successfully</div>";
        header("location:manage-admin.php");
    }
    else{
        header("location:add-admin.php");
    }
}

?>
