<?php include('menu.php');?>
<?php

$id = $_GET['id'];
$image = $_GET['image'];

if($image != ""){
    $path = '../images/category/'.$image;
    unlink($path);
}
    $query = "DELETE FROM tbl_category WHERE id = $id";
    if(mysql_query($query)){
        session_start();
        $_SESSION['message'] = "<div class='delete'>Category deleted successfully</div>";
        header("location:manage-category.php");
    }else{
        $_SESSION['message'] = "<div class='delete'>Category couldn't delete</div>";
        header("location:manage-category.php");
    }
?>