<?php include('connection.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/admin.css">
    <title>Login-Admin</title>
</head>
<body>
    <div class="login">
        <h1 class="text-center">Login Admin</h1>
        <br>
        <?php
            session_start();
            error_reporting(1);
            if($_SESSION['message']!=""){
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            }
            if($_SESSION['login_first']!=""){
                echo $_SESSION['login_first'];
                unset($_SESSION['login_first']);
            }
        ?>
        <br>
        <form action="" method="post" class="text-center">
            Username :  <input type="text" name="username" placeholder="Enter your name"><br><br>
            Password :  <input type="password" name="password" placeholder="Enter your password"><br><br>
            <input type="submit" value="Login" name="submit" class="btn-primary">
        </form>
        <br>
        <p class="text-center">Created by - <a href="#">Ridwan</a></p>
    </div>
</body>
</html>

<?php
session_start();
if(isset($_POST['submit'])){
    $name = $_POST['username'];
    $pwd = ($_POST['password']);
    $query = "SELECT id from tbl_admin WHERE username='$name' AND password='$pwd'";
    $result = mysql_query($query);
    if($result){
        if(mysql_num_rows($result) > 0){
            $_SESSION['login'] = "<div class='add'>Login Successfully</div>";
            header("location:index.php");
        }
        else{
            $_SESSION['message'] = "<div class='delete text-center'>User Not Found</div>";
            header("location:login.php");
        }
    }
}