<?php include('menu.php');?>


    <div class="main-content">
        <div class="wrapper">
            <h3>DASHBOARD</h3>
            <br>

            <?php
                $query = "SELECT * FROM tbl_admin";
                $result = mysql_query($query);
                $count = mysql_num_rows($result);
                echo "
                    <a href='manage-admin.php'>
                        <div class='col-4 text-center'>
                            <h1>$count</h1>
                            <p>Admins</p>
                        </div>
                    </a>
                ";
            ?>
            <?php
                $query = "SELECT * FROM tbl_category";
                $result = mysql_query($query);
                $count = mysql_num_rows($result);
                echo "
                    <a href='manage-category.php'>
                        <div class='col-4 text-center'>
                            <h1>$count</h1>
                            <p>Categories</p>
                        </div>
                    </a>
                ";
            ?>
            <?php
                $query = "SELECT * FROM tbl_food";
                $result = mysql_query($query);
                $count = mysql_num_rows($result);
                echo "
                    <a href='manage-food.php'>
                        <div class='col-4 text-center'>
                            <h1>$count</h1>
                            <p>Foods</p>
                        </div>
                    </a>
                ";
            ?>
            <?php
                $query = "SELECT * FROM tbl_order";
                $result = mysql_query($query);
                $count = mysql_num_rows($result);
                echo "
                    <a href='manage-order.php'>
                        <div class='col-4 text-center'>
                            <h1>$count</h1>
                            <p>Orders</p>
                        </div>
                    </a>
                ";
            ?>
            <div class="clear-fix"></div>

        </div>
    </div>

<?php include('footer.php');?>