<?php include('menu.php');?>
    <div class="main-content">
        <div class="wrapper">
            <h1>Manage Food</h1>
            <br>
            <?php
                error_reporting(1);
                if($_SESSION['message']!=""){
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                }
            ?>
            <br>
            <a href="add-food.php" class="btn-primary">Add food</a>
            <br><br>

            <table class="tbl-full">
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th style="width: 200px;">Description</th>
                    <th>Price</th>
                    <th>Image</th>
                    <th>Category_id</th>
                    <th>Featured</th>
                    <th>Active</th>
                    <th>Actions</th>
                </tr>
                <?php
                $query="SELECT * FROM tbl_food";
                $val=mysql_query($query);
                if(mysql_num_rows($val) <= 0){
                    echo "<tr><td colspan='9' class='delete text-center'>Food didn't add yet!!!</td></tr>";
                }
                else{
                    while(list($id,$title,$des,$price,$image,$cid,$feat,$act) = mysql_fetch_array($val))
                    {
                        if($image==""){
                            $image="<div class='delete'>Image didn't add!!!</div>";
                        }
                        else{
                            $temp_img = $image; 
                            $image="<img src='../images/food/$image' width='50px' height='50px'>";
                        }
                        echo "<tr>";
                            echo "<td>".$id."</td>";
                            echo "<td>".$title."</td>";
                            echo "<td>".$des."</td>";
                            echo "<td>".$price."</td>";
                            echo "<td>".$image."</td>";
                            echo "<td>".$cid."</td>";
                            echo "<td>".$feat."</td>";
                            echo "<td>".$act."</td>";
                            echo "
                                    <td>
                                        <a href='update-food.php?id=$id' class='btn-secondary'>Update Food</a>
                                        <a href='delete-food.php?id=$id&image=$temp_img' class='btn-danger'>Delete Food</a>
                                    </td>
                                ";
                        echo "</tr>";
                    }
                }
                ?>
            </table>
        </div>
    </div>
<?php include('footer.php');?>