<?php include('menu.php');?>
    <div class="main-content">
        <div class="wrapper">
            <h1>Manage Category</h1>
            <br>
            <?php
            error_reporting(1);
            if($_SESSION['message']!=""){
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            }
            ?>
            <br>
            <a href="add-category.php" class="btn-primary">Add Category</a>
            <br><br>

            <table class="tbl-full">
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Image</th>
                    <th>Featured</th>
                    <th>Active</th>
                    <th>Action</th>
                </tr>
                <?php
                $query="SELECT * FROM tbl_category";
                $val=mysql_query($query);
                $temp_img = "";
                while(list($id,$title,$image,$featured,$active) = mysql_fetch_array($val))
                {
                if($image==""){
                    $image="<div class='delete'>Image didn't add!!!</div>";
                }
                else{
                    $temp_img = $image; 
                    $image="<img src='../images/category/$image' width='50px' height='50px'>";
                }
                echo "<tr>";
                echo "<td>".$id."</td>";
                echo "<td>".$title."</td>";
                echo "<td>".$image."</td>";
                echo "<td>".$featured."</td>";
                echo "<td>".$active."</td>";
                echo "

                        <td>
                            <a href='update-category.php?id=$id' class='btn-secondary'>Update Category</a>
                            <a href='delete-category.php?id=$id&image=$temp_img' class='btn-danger'>Delete Category</a>
                        </td>
                    ";
                echo "</tr>";
                }
                ?>
            </table>
        </div>
    </div>
<?php include('footer.php');?>