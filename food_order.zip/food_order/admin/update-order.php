<?php include('menu.php');?>

<?php
    $id = $_GET['id'];
?>

    <div class="main-content">
        <div class="wrapper">
            <h1>Update Status</h1>

            <form action="" method="POST" enctype="multipart/form-data">
                <table class="tbl-40">
                    <tr>
                        <td>Status: </td>
                        <td>
                            <select name="status">
                                <?php
                                    $order = "";
                                    $onDeli = "";
                                    $deli = "";
                                    $cancel = "";

                                    $query="SELECT status FROM tbl_order WHERE id = $id";
                                    $val=mysql_query($query);
                                    list($s) = mysql_fetch_array($val);
                                    echo $s;
                                    if($s == "Ordered"){
                                        $order = "selected";
                                    }
                                    else if($s == "On Delivery"){
                                        $onDeil = "selected";
                                    }
                                    else if($s == "Delivered"){
                                        $deli = "selected";
                                    }
                                    else if($s == "Cancelled"){
                                        $cancel = "selected";
                                    }
                                    echo "<option $order value='Ordered'>Ordered</option>";
                                    echo "<option $onDeil value='On Delivery'>On Delivery</option>";
                                    echo "<option $deli value='Delivered'>Delivered</option>";
                                    echo "<option $cancel value='Cancelled'>Cancelled</option>";
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colspan=2>
                            <input type="submit" name="submit" value="Update Food" class="btn-secondary">
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
<?php include('footer.php');?>

<?php

if(isset($_POST['submit'])){
    session_start();
    $id = $_GET['id'];
    $status = $_POST['status'];
    $query = "UPDATE tbl_order SET status='$status' WHERE id=$id";
    $result = mysql_query($query);
    if($result){
        $_SESSION['message'] = "<div class='add'>Updated Order_Status successfully</div>";
        header("location:manage-order.php");
    }
    else{
        $_SESSION['message'] = "<div class='delete'>Failed update food</div>";
        header("location:manage-order.php");
    }
}
?>