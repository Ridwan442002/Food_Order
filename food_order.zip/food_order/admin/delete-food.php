<?php include('menu.php');?>
<?php

$id = $_GET['id'];
$image = $_GET['image'];

if($image != ""){
    $path = '../images/food/'.$image;
    unlink($path);
}
    $query = "DELETE FROM tbl_food WHERE id = $id";
    if(mysql_query($query)){
        session_start();
        $_SESSION['message'] = "<div class='delete'>Food deleted successfully</div>";
        header("location:manage-food.php");
    }else{
        $_SESSION['message'] = "<div class='delete'>Food couldn't delete</div>";
        header("location:manage-food.php");
    }
?>