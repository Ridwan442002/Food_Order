<?php include('menu.php');?>

<?php
    $id = $_GET['id'];
    $query="SELECT title,image_name,featured,active FROM tbl_category WHERE id = $id";
    $val=mysql_query($query);
    list($t,$i,$f,$a) = mysql_fetch_array($val);
?>

    <div class="main-content">
        <div class="wrapper">
            <h1>Update Admin</h1>

            <form action="" method="POST" enctype="multipart/form-data">
                <table class="tbl-40">
                    <tr>
                        <td>Title: </td>
                        <td><input type="text" name="title" value="<?php echo $t?>"></td>
                        <td></td>
                    </tr>
                    <tr>
                    <td>Image : </td>
                    <td>
                        <?php
                        if($i != ""){
                            ?>
                            <img src='../images/category/<?php echo $i?>' width='100px' height='100px'>
                            <?php
                        }
                        else{
                            echo "<div class='delete'>Image didn't add</div>";
                        }
                        ?>
                        <br>
                        <input type="file" name="image">
                    </td>
                </tr>
                <tr>
                    <td>Featured : </td>
                    <td>
                        <input <?php if($f=="Yes"){echo "checked";}?> type="radio" name="featured" value="Yes"> Yes
                        <input <?php if($f==="No"){echo "checked";}?> type="radio" name="featured" value="No"> No
                    </td>
                </tr>
                <tr>
                    <td>Active : </td>
                    <td>
                        <input <?php if($a=="Yes"){echo "checked";}?> type="radio" name="active" value="Yes"> Yes
                        <input <?php if($a=="No"){echo "checked";}?> type="radio" name="active" value="No"> No
                    </td>
                </tr>
                <tr>
                    <td colspan=2>
                        <input type="submit" name="submit" value="Update Category" class="btn-secondary">
                    </td>
                </tr>
                </table>
            </form>
        </div>
    </div>
<?php include('footer.php');?>

<?php

if(isset($_POST['submit'])){
    $title = $_POST['title'];
    if(isset($_POST['featured'])){
        $featured = $_POST['featured'];
    }
    else{
        $featured = "No";
    }
    if(isset($_POST['active'])){
        $active = $_POST['active'];
    }
    else{
        $active = "No";
    }

    if(isset($_FILES['image']['name'])){
        $image = $_FILES['image']['name'];
        if($image != ""){
            $ext = end(explode('.',$image));
            $image = "Food_".rand(111,999).".".$ext;
            $source = $_FILES['image']['tmp_name'];
            $path = '../images/category/'.$image;
            $upload = move_uploaded_file($source,$path);
            if(!$upload){
                $_SESSION['message'] = "<div class='delete'>Failed upload image</div>";
                header("<location:manage></location:manage>-category.php");
                die();
            }

            if($i != ""){
                $rpath = '../images/category/'.$i;
                unlink($rpath);
            }
        }
        else{
            $image = $i;
        }
    }
    else{
        $image = $i;
    }

    $query = "UPDATE tbl_category SET title='$title',image_name='$image',featured='$featured',active='$active' WHERE id=$id";
    $result = mysql_query($query);
    if($result){
        $_SESSION['message'] = "<div class='add'>Updated category successfully</div>";
        header("location:manage-category.php");
    }
    else{
        $_SESSION['message'] = "<div class='delete'>Failed update category</div>";
        header("location:manage-category.php");
    }
}
?>