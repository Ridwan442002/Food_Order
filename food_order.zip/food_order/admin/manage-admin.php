<?php include('menu.php')?>
    <div class="main-content">
        <div class="wrapper">
            <h1>Manage Admin</h1>

            <br>
            <?php
            error_reporting(1);
            if($_SESSION['message']!=""){
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            }
            ?>
            <br>

            <a href="add-admin.php" class="btn-primary">Add admin</a>
            <br><br>

            <table class="tbl-full">
                <tr>
                    <th>ID</th>
                    <th>Fullname</th>
                    <th>Username</th>
                    <th>Actions</th>
                </tr>
                <?php
                $query="SELECT id,full_name,username FROM tbl_admin";
                $val=mysql_query($query);
                while(list($id,$fname,$uname) = mysql_fetch_array($val))
                {
                echo "<tr>";
                echo "<td>".$id."</td>";
                echo "<td>".$fname."</td>";
                echo "<td>".$uname."</td>";
                echo "
                        <td>
                            <a href='change-password.php?id=$id' class='btn-pwd'>Change Password</a>
                            <a href='update-admin.php?id=$id' class='btn-secondary'>Update Admin</a>
                            <a href='delete-admin.php?id=$id' class='btn-danger'>Delete Admin</a>
                        </td>
                    ";
                echo "</tr>";
                }
                ?>
            </table>
        </div>
    </div>
<?php include('footer.php');?>