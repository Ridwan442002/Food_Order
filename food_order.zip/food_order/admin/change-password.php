<?php include('menu.php');?>

<div class="main-content">
        <div class="wrapper">
            <h1>Change Password</h1>
            <br>
            <?php
                session_start();
                error_reporting(1);
                if($_SESSION['message']!=""){
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                }
            ?>
            <br>
            <form action="" method="POST">
                <table class="tbl-40">
                    <tr>
                        <td>Old Password: </td>
                        <td><input type="password" name="opassword" placeholder="Enter a old password"></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>New Password: </td>
                        <td><input type="password" name="npassword" placeholder="Enter a new password"></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Confirm Password: </td>
                        <td><input type="password" name="cpassword" placeholder="Enter a confirm password"></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <input type="submit" value="Change password" name="submit" class="btn-secondary">
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
<?php include('footer.php');?>

<?php
session_start();
$id = $_GET['id'];
if(isset($_POST['submit'])){
    $old = md5($_POST['opassword']);
    $new = md5($_POST['npassword']);
    $confirm = md5($_POST['cpassword']);

    $check = "SELECT * from tbl_admin WHERE id=$id AND password='$old'";
    $result = mysql_query($check);
    if($result && mysql_num_rows($result)){
        if($new === $confirm){
            $query = "UPDATE tbl_admin SET password='$new' WHERE id=$id";
            if(mysql_query($query)){
                $_SESSION['message'] = "<div class='add'>Password Changed Successfully</div>";
                header("location:manage-admin.php");
            }
            else{
                echo "Error: ".mysql_error();
            }
        }
        else{
            $_SESSION['message'] = "<div class='delete'>New Password and Confirm Password didn't match!!!</div>";
            header("location:manage-admin.php");
        }
    }
    else{
        $_SESSION['message'] = "<div class='delete'>User Not Found</div>";
        header("location:manage-admin.php");
    }
}

?>