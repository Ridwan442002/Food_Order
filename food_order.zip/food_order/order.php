<?php include('menu.php');?>
<?php
    $id = $_GET['id'];
?>
    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search">
        <div class="container">
            
            <h2 class="text-center text-white">Fill this form to confirm your order.</h2>

            <form action="#" class="order" method="POST">
                <fieldset>
                    <legend>Selected Food</legend>

                    <?php
                        $query="SELECT title,price,image_name FROM tbl_food WHERE id=$id";
                        $val=mysql_query($query);
                        if(mysql_num_rows($val) <= 0){
                            echo "<tr><td colspan='9' class='delete text-center'>Food didn't add yet!!!</td></tr>";
                        }
                        else{
                            while(list($title,$price,$image) = mysql_fetch_array($val))
                            {
                                if($image==""){
                                    $image="<div class='delete'>Image didn't add!!!</div>";
                                }
                                else{ 
                                    $image= $image="<img src='images/food/$image' alt='$title' class='img-responsive img-curve'>";
                                }
                            echo "<div class='food-menu-img'>
                                    $image
                                </div>
                
                                <div class='food-menu-desc'>
                                    <h3>$title</h3>
                                    <input type='hidden' name='food' value='$title'>

                                    <p class='food-price'> $$price</p>
                                    <input type='hidden' name='price' value='$price'>

                                    <div class='order-label'>Quantity</div>
                                    <input type='number' name='qty' class='input-responsive' value='1' required>  
                                </div>

                            </fieldset>";
                            }
                        }
                    ?>
                
                <fieldset>
                    <legend>Delivery Details</legend>
                    <div class="order-label">Full Name</div>
                    <input type="text" name="fullname" placeholder="E.g. Minthu" class="input-responsive" required>

                    <div class="order-label">Phone Number</div>
                    <input type="tel" name="contact" placeholder="E.g. 0989xxxxxx" class="input-responsive" required>

                    <div class="order-label">Email</div>
                    <input type="email" name="email" placeholder="E.g. lwisd755@gmail.com" class="input-responsive" required>

                    <div class="order-label">Address</div>
                    <textarea name="address" rows="10" placeholder="E.g. Street, City, Country" class="input-responsive" required></textarea>

                    <input type="submit" name="submit" value="Confirm Order" class="btn btn-primary">
                </fieldset>

            </form>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->

<?php

if(isset($_POST['submit'])){
    $food = $_POST['food'];
    $price = $_POST['price'];
    $qty = $_POST['qty'];
    $total = $price * $qty;
    $status = "Ordered";
    $fullname = $_POST['fullname'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    $query = "INSERT INTO tbl_order(food,price,qty,total,status,customer_name,customer_contact,customer_email,customer_address) VALUES('$food',$price,$qty,$total,'$status','$fullname','$contact','$email','$address')";

    session_start();
    $result = mysql_query($query);
    if($result){
        $_SESSION['order'] = "<h3 class='success text-center'>Ordered Successfully</h3>";
        header("location:index.php");
    }
    else{
        $_SESSION['order'] = "<h3 class='fail text-center'>Failed Order</h3>";
        header("location:index.php");
    }
}

?>

<?php include('footer.php');?>