<?php include('menu.php');?>
<?php
    $id = $_GET['id'];
    $title = $_GET['title'];
?>
    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <h2>Foods on <a href="#" class="text-white"> "<?php echo $title ?>"</a></h2>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->



    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>

            <?php
                $query="SELECT id,title,description,price,image_name FROM tbl_food WHERE category_id=$id";
                $val=mysql_query($query);
                if(mysql_num_rows($val) <= 0){
                    echo "<div class='text-center'>No Food What You Search</div>";
                }
                else{
                    while(list($id,$title,$des,$price,$image) = mysql_fetch_array($val))
                    {
                        if($image==""){
                            $image="<div class='delete'>Image didn't add!!!</div>";
                        }
                        else{ 
                            $image= $image="<img src='images/food/$image' alt='$title' class='img-responsive img-curve'>";
                        }
                    echo "<div class='food-menu-box'>
                            <div class='food-menu-img'>
                                $image
                            </div>

                            <div class='food-menu-desc'>
                                <h4>$title</h4>
                                <p class='food-price'>$price $</p>
                                <p class='food-detail'>$des</p>
                                <br>
                                <a href='order.php' class='btn btn-primary'>Order Now</a>
                            </div>
                        </div>";
                    }
                }
            ?>
            <div class="clearfix"></div>
        </div>

    </section>
    <!-- fOOD Menu Section Ends Here -->
<?php include('footer.php');?>