<?php include('menu.php');?>
    <section class="food-search text-center">
        <div class="container">
            <form action="food-search.php" method="post">
                <input type="search" name="search" placeholder="Search For Food...." required>
                <input type="submit" value="Search" name="submit" class="btn btn-primary">
            </form>
        </div>
    </section><br>

    <?php
        session_start();
        if(isset($_SESSION['order'])){
            echo $_SESSION['order'];
            unset($_SESSION['order']);
        }
    ?>

    <!-- CAtegories Section Starts Here -->
    <section class="categories">
        <div class="container">
            <h2 class="text-center">Explore Foods</h2>

            <?php
                $query="SELECT id,title,image_name FROM tbl_category WHERE featured='Yes' AND active ='Yes' LIMIT 3";
                $val=mysql_query($query);
                while(list($id,$title,$image) = mysql_fetch_array($val))
                {
                    if($image==""){
                        $image="<div class='delete'>Image Not Available</div>";
                    }
                    else{ 
                        $image="<img src='images/category/$image' alt='$title' class='img-responsive img-curve'>";
                    }
                echo "<a href='category-foods.php?id=$id&title=$title'>
                        <div class='box-3 float-container'>
                            $image
                            <h3 class='float-text text-white'>$title</h3>
                        </div>
                    </a>";
                }
            ?>

            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Categories Section Ends Here -->

    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>

            <?php
                $query="SELECT id,title,description,price,image_name FROM tbl_food WHERE featured='Yes' AND active='Yes' LIMIT 6";
                $fid=0;
                $val=mysql_query($query);
                if(mysql_num_rows($val) <= 0){
                    echo "<tr><td colspan='9' class='delete text-center'>Food didn't add yet!!!</td></tr>";
                }
                else{
                    while(list($id,$title,$des,$price,$image) = mysql_fetch_array($val))
                    {
                        $fid = $id;
                        if($image==""){
                            $image="<div class='delete'>Image didn't add!!!</div>";
                        }
                        else{ 
                            $image= $image="<img src='images/food/$image' alt='$title' class='img-responsive img-curve'>";
                        }
                    echo "<div class='food-menu-box'>
                            <div class='food-menu-img'>
                                $image
                            </div>

                            <div class='food-menu-desc'>
                                <h4>$title</h4>
                                <p class='food-price'>$price $</p>
                                <p class='food-detail'>$des</p>
                                <br>
                                <a href='order.php?id=$id' class='btn btn-primary'>Order Now</a>
                            </div>
                        </div>";
                    }
                }
            ?>
            <div class="clearfix"></div>
        </div>

        <p class="text-center">
            <a href="#">See All Foods</a>
        </p>
    </section>
    <!-- fOOD Menu Section Ends Here -->
<?php include('footer.php');?>